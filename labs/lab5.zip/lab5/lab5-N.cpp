#include <bits/stdc++.h>

using namespace std;

int main()
{
    string s;
    cin >> s;
    string welcome = "Welcome ";
    string result = welcome.append(s);
    cout << result;
    return 0;
}